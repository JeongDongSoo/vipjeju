<?php
if (!defined('_GNUBOARD_')) exit;
$bo_subject='공지사항';
$list=array (
  0 => 
  array (
    'wr_id' => '1',
    'wr_num' => '-1',
    'wr_reply' => '',
    'wr_parent' => '1',
    'wr_is_comment' => '0',
    'wr_comment' => '0',
    'wr_comment_reply' => '',
    'ca_name' => '',
    'wr_option' => '',
    'wr_subject' => 'VIP제주여행  환불규정입니다.',
    'wr_content' => '<VIP제주여행 환불규정> 

당일 취소시 환불수수료 X 100% 환불가능! 

한국 소비자 보호기준 24시간이내 취소시에는 10%의 환불수수료가 적용이되나 
저희 제주신화렌트카에서는 그 10%을 없애고 24시간이내 취소시에도 100% 환불이 진행됩니다. 

※단! 추석,설날,연휴 / 성수기 제외! 

차량이용일 기준 5일전 취소시에는 100%환불 

4 일전 : 10%적용  
3 일전 : 20%적용  
2 일전 : 30%적용  
1 일전 : 40%적용  

★당  일 : 50%적용★      

* 성수기와 연휴기간에는 5일이전 일정변경시에도 전체금액에서 취소,변경수수료 적용됩니다 ! 
  (전체금액에서 수수료적용) 

<단, 천재지변에 의한 항공,선박결항시에는 환불수수료가 적용이 되지 않습니다.>      

P.S 예약취소와 조기반납관련 환불진행은 매주 목요일에 진행이 되고 있습니다. 
      목요일에 취소하시는 경우 당일 환불금액을 받아 보실 수 있으나, 금요일 취소하셨을 경우 
      돌아오는 다음주 ★목요일★에 환불받아 보실 수 있습니다. 

※ 환불진행일인 목요일 환불절차가 전부 완료가 되는 시점 이후에 환불요청시에는 
    다음주 목요일로 적용이 되오니 유의 부탁드립니다. 

감사합니다.',
    'wr_link1' => '',
    'wr_link2' => '',
    'wr_link1_hit' => '0',
    'wr_link2_hit' => '0',
    'wr_hit' => '8',
    'wr_good' => '0',
    'wr_nogood' => '0',
    'mb_id' => 'admin',
    'wr_password' => '*9BE72CA17D7601C9CBA6F4B7D7559B542BBFAED9',
    'wr_name' => '최고관리자',
    'wr_email' => 'admin@domain.com',
    'wr_homepage' => '',
    'wr_datetime' => '2016-04-26 16:53:14',
    'wr_file' => '0',
    'wr_last' => '2016-04-26 16:53:14',
    'wr_ip' => '118.43.242.245',
    'wr_facebook_user' => '',
    'wr_twitter_user' => '',
    'wr_1' => '',
    'wr_2' => '',
    'wr_3' => '',
    'wr_4' => '',
    'wr_5' => '',
    'wr_6' => '',
    'wr_7' => '',
    'wr_8' => '',
    'wr_9' => '',
    'wr_10' => '',
    'is_notice' => true,
    'subject' => 'VIP제주여행  환불규정입니다.',
    'comment_cnt' => '',
    'datetime' => '2016-04-26',
    'datetime2' => '04-26',
    'last' => '2016-04-26',
    'last2' => '04-26',
    'name' => '<span class="sv_member">최고관리자</span>',
    'reply' => 0,
    'icon_reply' => '',
    'icon_link' => '',
    'ca_name_href' => 'http://vipjeju.co.kr/include/bbs/board.php?bo_table=notice&amp;sca=',
    'href' => 'http://vipjeju.co.kr/include/bbs/board.php?bo_table=notice&amp;wr_id=1',
    'comment_href' => 'http://vipjeju.co.kr/include/bbs/board.php?bo_table=notice&amp;wr_id=1',
    'icon_new' => '',
    'icon_hot' => '',
    'icon_secret' => '',
    'link' => 
    array (
      1 => NULL,
      2 => NULL,
    ),
    'link_href' => 
    array (
      1 => 'http://vipjeju.co.kr/include/bbs/link.php?bo_table=notice&amp;wr_id=1&amp;no=1',
      2 => 'http://vipjeju.co.kr/include/bbs/link.php?bo_table=notice&amp;wr_id=1&amp;no=2',
    ),
    'link_hit' => 
    array (
      1 => 0,
      2 => 0,
    ),
    'file' => 
    array (
      'count' => '0',
    ),
  ),
)?>