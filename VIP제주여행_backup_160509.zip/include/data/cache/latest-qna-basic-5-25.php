<?php
if (!defined('_GNUBOARD_')) exit;
$bo_subject='여행상담문의';
$list=array (
)?>