<?php
if (!defined('_GNUBOARD_')) exit;
$bo_subject='맛집정보';
$list=array (
)?>