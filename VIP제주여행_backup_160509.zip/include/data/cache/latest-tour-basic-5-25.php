<?php
if (!defined('_GNUBOARD_')) exit;
$bo_subject='여행정보';
$list=array (
)?>