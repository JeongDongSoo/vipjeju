<?php
$menu['menu400'] = array (
    array('400000', '차량관리', '/rent/adm/car_list.php', 'car'),
    array('400100', '차종관리', '/rent/adm/car_list.php', 'car_list'),
    array('400200', '차종분류관리', '/rent/adm/kind_code.php', 'kind_code'),
    array('400200', '자차보험관리', '/rent/adm/insure_list.php', 'insure_list'),
    array('400300', '할인기간관리', '/rent/adm/discount_season.php', 'discount_season', 1),
    array('400400', '대여료할인율관리', '/rent/adm/discount_rate.php', 'discount_rate', 1),
    array('400400', '자차할인율관리', '/rent/adm/insure_discount_rate.php', 'discount_rate', 1),
    array('400500', '배반차요금설정', '/rent/adm/set_out_fee.php', 'set_out_fee', 1),
);
?>