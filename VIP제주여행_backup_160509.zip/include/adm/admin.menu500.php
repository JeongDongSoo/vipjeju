<?php
$menu['menu500'] = array (
    array('500000', '예약관리', '/rent/adm/reserve_list.php', 'reserve'),
    array('500100', '예약관리', '/rent/adm/reserve_list.php', 'reserve_list'),
);
?>