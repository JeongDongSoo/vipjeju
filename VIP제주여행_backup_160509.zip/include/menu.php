<ul class="depth2">
	<li><a href="#">렌터카</a>
		<ul>
		<li><a href="/rent/car_list.php">예약하기</a></li>
		<li><a href="/rent/rent_info.php">대여안내</a></li>
		<li><a href="/rent/insurance.php">자차보험안내</a></li>
		</ul>
	</li>
	<li><a href="javascript:menu_wait()">카텔패키지</a>
		<ul>
		<li><a href="javascript:menu_wait()">항공+렌터카</a></li>
		<li><a href="javascript:menu_wait()">항공+숙소</a></li>
		<li><a href="javascript:menu_wait()">렌터카+숙소</a></li>
		</ul>
	</li>
	<li><a href="javascript:menu_wait()">숙소</a>
		<ul>
		<li><a href="javascript:menu_wait()">베스트숙소</a></li>
		<li><a href="javascript:menu_wait()">호텔</a></li>
		<li><a href="javascript:menu_wait()">리조트</a></li>
		<li><a href="javascript:menu_wait()">펜션</a></li>
		</ul>
	</li>
	<li><a href="javascript:menu_wait()">골프</a>
		<ul>
		<li><a href="javascript:menu_wait()">전체상품</a></li>
		<li><a href="javascript:menu_wait()">1박2일</a></li>
		<li><a href="javascript:menu_wait()">2박3일</a></li>
		<li><a href="javascript:menu_wait()">명문패키지</a></li>
		</ul>
	</li>
	<li><a href="javascript:menu_wait()">버스</a>
		<ul>
		<li><a href="javascript:menu_wait()">카운티</a></li>
		<li><a href="javascript:menu_wait()">중형버스</a></li>
		<li><a href="javascript:menu_wait()">대형버스</a></li>
		<li><a href="javascript:menu_wait()">VIP리무진</a></li>
		</ul>
	</li>
	<li><a href="javascript:menu_wait()">택시</a>
		<ul>
		<li><a href="javascript:menu_wait()">택시</a></li>
		</ul>
	</li>
	<li><a href="javascript:menu_wait()">관광지입장권</a>
		<ul>
		<li><a href="javascript:menu_wait()">관광지입장권</a></li>
		</ul>
	</li>
	<li><a href="javascript:menu_wait()">단체여행</a>
		<ul>
		<li><a href="javascript:menu_wait()">단체여행</a></li>
		</ul>
	</li>
	<li><a href="#">고객센터</a>
		<ul>
		<li><a href="/include/bbs/board.php?bo_table=notice">공지사항</a></li>
		<li><a href="/include/bbs/board.php?bo_table=tour">여행상담문의</a></li>
		<li><a href="/include/bbs/board.php?bo_table=faq">FAQ</a></li>
		<li><a href="/include/bbs/board.php?bo_table=event">이벤트</a></li>	
		<li><a href="/include/bbs/board.php?bo_table=tour">여행정보</a></li>
		<li><a href="/include/bbs/board.php?bo_table=food">맛집정보</a></li>
		</ul>
	</li>
</ul>